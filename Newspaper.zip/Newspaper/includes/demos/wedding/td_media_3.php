<?php

// featured images
td_demo_media::add_image_to_media_gallery('td_pic_11',                   "http://demo_content.tagdiv.com/Newspaper_6/wedding/11.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_12',                   "http://demo_content.tagdiv.com/Newspaper_6/wedding/12.jpg");

// post photos
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/p2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/p3.jpg");