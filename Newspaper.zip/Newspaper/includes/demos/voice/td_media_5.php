<?php

//homepage images
td_demo_media::add_image_to_media_gallery('td_pic_homepage_0',                 "http://demo_content.tagdiv.com/Newspaper_6/voice/homepage0.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_homepage_1',                 "http://demo_content.tagdiv.com/Newspaper_6/voice/homepage1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_homepage_2',                 "http://demo_content.tagdiv.com/Newspaper_6/voice/homepage2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_homepage_3',                 "http://demo_content.tagdiv.com/Newspaper_6/voice/homepage3.jpg");


// ads
td_demo_media::add_image_to_media_gallery('td_voice_ad',                       "http://demo_content.tagdiv.com/Newspaper_6/voice/reclama.jpg");
td_demo_media::add_image_to_media_gallery('td_voice_sidebar_ad',               "http://demo_content.tagdiv.com/Newspaper_6/voice/reclama-sidebar.jpg");

