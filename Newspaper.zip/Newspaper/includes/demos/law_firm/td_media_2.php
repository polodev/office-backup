<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_section_practice_areas',      "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/section-practice-areas.jpg");
td_demo_media::add_image_to_media_gallery('td_section_ceo',                 "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/section-ceo.jpg");
td_demo_media::add_image_to_media_gallery('td_section_choose_us',           "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/section-choose-us.jpg");
td_demo_media::add_image_to_media_gallery('td_section_consultation',        "http://demo_content.tagdiv.com/Newspaper_multi/law_firm/section-consultation.jpg");



