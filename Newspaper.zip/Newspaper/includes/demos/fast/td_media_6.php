<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',                     "http://demo_content.tagdiv.com/Newspaper_6/fast/logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',              "http://demo_content.tagdiv.com/Newspaper_6/fast/logo-retina.png");

td_demo_media::add_image_to_media_gallery('td_footer_bg',                     "http://demo_content.tagdiv.com/Newspaper_6/fast/footer-bg.jpg");
