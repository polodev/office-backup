<?php


td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/gaming/9.jpg");

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/gaming/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newspaper_6/gaming/p2.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/gaming/logo-header.png');