<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_6/gaming/logo-header@2x.png');
td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/gaming/logo-footer.png');

// ads
td_demo_media::add_image_to_media_gallery('td_rec_bg',                  'http://demo_content.tagdiv.com/Newspaper_6/gaming/rec-bg.png');