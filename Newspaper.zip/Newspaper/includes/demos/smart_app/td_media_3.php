<?php
td_demo_media::add_image_to_media_gallery('td_pic_10',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/feature-iphone.png");
td_demo_media::add_image_to_media_gallery('td_pic_11',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/feature-mac.png");
td_demo_media::add_image_to_media_gallery('td_pic_12',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/features-img.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_13',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/features-devices.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/feature-servers.png");
td_demo_media::add_image_to_media_gallery('price-hero',                    "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_price-hero_xxx.jpg");