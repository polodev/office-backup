<?php
td_demo_media::add_image_to_media_gallery('td_post_1',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post1.jpg");
td_demo_media::add_image_to_media_gallery('td_post_2',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post2.jpg");
td_demo_media::add_image_to_media_gallery('td_post_3',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post3.jpg");
td_demo_media::add_image_to_media_gallery('td_post_4',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post4.jpg");
td_demo_media::add_image_to_media_gallery('td_post_5',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post5.jpg");