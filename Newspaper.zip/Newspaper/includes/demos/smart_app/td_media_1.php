<?php
/**
 * Created by ra on 5/14/2015.
 */

td_demo_media::add_image_to_media_gallery('homepage-hero',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_homepage-hero_xxx.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_2',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/hero.png");
td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/iphone.png");
td_demo_media::add_image_to_media_gallery('homepage-clients',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_homepage-clients_xxx.jpg");
td_demo_media::add_image_to_media_gallery('bg_mobile',                  "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/bg-mobile.jpg");
td_demo_media::add_image_to_media_gallery('video-overlay',              "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_video-overlay_xxx.png");