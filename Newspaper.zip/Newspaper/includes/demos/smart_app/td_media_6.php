<?php
td_demo_media::add_image_to_media_gallery('td_post_6',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post6.jpg");
td_demo_media::add_image_to_media_gallery('td_post_7',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post7.jpg");
td_demo_media::add_image_to_media_gallery('td_post_8',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post8.jpg");
td_demo_media::add_image_to_media_gallery('td_post_9',                   "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/post9.jpg");