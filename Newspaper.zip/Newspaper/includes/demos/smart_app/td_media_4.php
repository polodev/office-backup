<?php
// logos
td_demo_media::add_image_to_media_gallery('video-lessons',                  "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_video-lessons_xxx.jpg");
td_demo_media::add_image_to_media_gallery('download_hero',                  "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/xxx_download_hero_xxx.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_17',                  "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/support-hero.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_18',                  "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/download-screen.jpg");
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/logo-white-small.png");
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      "http://demo_content.tagdiv.com/Newspaper_multi/smart_app/logo.png");