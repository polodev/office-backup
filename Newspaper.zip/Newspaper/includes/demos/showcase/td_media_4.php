<?php
/**
 * Created by ra on 6/13/2015.
 */


td_demo_media::add_image_to_media_gallery('pattern2',            'http://demo_content.tagdiv.com/Newspaper_multi/showcase/td-pattern-bg2.jpg');