<?php
td_demo_media::add_image_to_media_gallery('project1',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/project1.jpg");
td_demo_media::add_image_to_media_gallery('project2',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/project2.jpg");
td_demo_media::add_image_to_media_gallery('project3',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/project3.jpg");
td_demo_media::add_image_to_media_gallery('project4',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/project4.jpg");

td_demo_media::add_image_to_media_gallery('service1',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/service1.jpg");
td_demo_media::add_image_to_media_gallery('service2',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/service2.jpg");
td_demo_media::add_image_to_media_gallery('service3',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/service3.jpg");
