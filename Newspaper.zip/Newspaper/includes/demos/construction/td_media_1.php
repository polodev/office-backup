<?php
/**
 * Created by ra on 5/14/2015.
 */

td_demo_media::add_image_to_media_gallery('home-architecture',          "http://demo_content.tagdiv.com/Newspaper_multi/construction/home-architecture.jpg");
td_demo_media::add_image_to_media_gallery('home-garden',                "http://demo_content.tagdiv.com/Newspaper_multi/construction/home-garden.jpg");
td_demo_media::add_image_to_media_gallery('home-deliver',               "http://demo_content.tagdiv.com/Newspaper_multi/construction/home-deliver.jpg");
td_demo_media::add_image_to_media_gallery('signature',                  "http://demo_content.tagdiv.com/Newspaper_multi/construction/signature.png");
