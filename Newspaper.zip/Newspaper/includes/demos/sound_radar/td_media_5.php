<?php
/**
 * Created by ra on 6/13/2015.
 */

//ads
td_demo_media::add_image_to_media_gallery('td_header_ad',              "http://demo_content.tagdiv.com/Newspaper_6/sound_radar/rec-header.png");
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',             "http://demo_content.tagdiv.com/Newspaper_6/sound_radar/rec-sidebar.png");