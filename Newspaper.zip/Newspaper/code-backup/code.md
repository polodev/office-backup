# Lesson 

* php code will be written as same indentation as php start 


# callback for 
~~~php
  wp_nav_menu(array(
      'theme_location' => 'header-menu',
      'menu_class'=> 'sf-menu',
      'fallback_cb' => 'td_wp_page_menu',
      'walker' => new td_tagdiv_walker_nav_menu()
  ));


  //if no menu
  function td_wp_page_menu() {
      //this is the default menu
      if ( is_user_logged_in() ) {
        echo '<ul class="sf-menu">';
        echo '<li class="menu-item-first"><a href="' . esc_url( home_url( '/' ) ) . 'wp-admin/nav-menus.php?action=locations">Click here - to select or create a menu</a></li>';
        echo '</ul>';
      }
  }
~~~
